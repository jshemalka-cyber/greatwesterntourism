Merged site for main branch.
- styles.css?v=2 cache bust in all pages
- flag: assets/images/flag-sl.gif
- bg map: assets/images/bg-map.jpg (with dark overlay)
- Add your logo file p22.jpg at repo root.
